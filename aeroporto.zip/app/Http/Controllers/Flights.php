<?php

namespace App\Http\Controllers;

use App\Models\Airline;
use App\Models\Destination;
use App\Models\Flight;
use App\Models\Gate;
use App\Models\Log;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class Flights extends Controller
{


    public function getFlights()
    {
        $flights = Flight::with('gates', 'airline', 'destiny1', 'destiny2')->get();
        
        $destiny = Destination::get();
        $airline = Airline::get();
        $gate = Gate::get();

        return view('pages.flights', [
            'dataset' => $flights,
            'destinys' => $destiny,
            'airlines' => $airline,
            'gates'    => $gate,
        ]);
    }

    public function postFlight(Request $request)
    {
        $request->validate([
            'flight'   => ['required'],
            'destiny'  => ['required', 'numeric'],
            'airline'  => ['required', 'numeric'],
            'type'     => 'required',
        ]);

        if ($request->has('gate') || $request->type == 'departure') {
            $request->validate([
                'gate'     => ['required', 'numeric'],
            ]);
        }

        if (!empty($request->destiny2) && !is_numeric($request->destiny2)) return back()->withErrors('the second destiny field must to be a number');

        $i = 0;
        $num = [];
        while (true) {
            if (!isset($request->flight[$i])) break;
            $num[] = $request->flight[$i];
            $i++;
        }

        $obFlight = new Flight;
        $obFlight->flight            = implode(',', $num);
        $obFlight->flight_airline_id = $request->airline;
        $obFlight->flight_destiny_id = $request->destiny;
        if (!empty($request->destiny2)) $obFlight->flight_destiny2_id = $request->destiny2;
        $obFlight->flight_gate_id    = $request->gate;
        $obFlight->type              = $request->type;

        if ($obFlight->save()) {
            Log::create([
                'afect'   => 'flights',
                'context' => 'flight ['. $request->reason . '] was created',
                'type'    => 'added',
                'fk_user' => Auth::user()->id,
            ]);
            return back()->with('message', 'Flights was successfully added.');
        }

        return back()->withErrors('An error occurred while adding the flight');
    }

    public function updateFlight(Request $request, $id)
    {
        $request->validate([
            'flight'  => ['required', 'numeric'],
            'airline' => ['required', 'numeric'],
            'destiny' => ['required', 'numeric'],
            'type'    => ['required']
        ]);

        if ($request->has('gate') || $request->type == 'departure') {
            $request->validate([
                'gate'     => ['required', 'numeric'],
            ]);
        }

        $i = 0;
        $num = [];
        while (true) {
            if (!isset($request->flight[$i])) break;
            $num[] = $request->flight[$i];
            $i++;
        }

        $obFlight = Flight::findOrFail($id);
        $obFlight->flight_gate_id    = $request->gate;
        $obFlight->flight_airline_id = $request->airline;
        $obFlight->flight_destiny_id = $request->destiny;
        $obFlight->flight_destiny2_id = $request->destiny2 == 'null' ? null : $request->destiny2;
        $obFlight->flight             = implode(',', $num);
        $obFlight->type               = $request->type;
        $obFlight->save();

        Log::create([
            'afect'   => 'flights',
            'context' => 'flight ['. $request->flight . '] was updated',
            'type'    => 'updated',
            'fk_user' => Auth::user()->id,
        ]);

        return back()->with('message', 'flight was succesfully updated');
    }

    public function deleteFlight($id)
    {
        Flight::findOrFail($id)->delete();
        return back();
    }
}
