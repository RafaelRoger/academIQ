<?php

namespace App\Http\Controllers;

use App\Models\Airline;
use App\Models\Destination;
use \App\Models\Gate;
use App\Models\Log;
use App\Models\Reason;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class Settings extends Controller
{

    public function getDestinyLayout()
    {
        $destinys = Destination::get();

        return view('pages/destiny', [
            'destinys' => $destinys
        ]);
    }
    /**
     * METODO RESPONSAVEL POR RETORNAR A VISAO REASON
     */
    public function getReasonLayout()
    {
        $reasons = Reason::get();

        return view('pages/reasons', [
            'reasons' => $reasons
        ]);
    }

    public function getGateLayout()
    {

        $gates = Gate::get();

        return view('pages/gates', [
            'gates' => $gates
        ]);
    }

    /**
     * METODO RESPONSAVEL POR RETORNAR A VISÃO DE GERENCIAMENTO DE AIRLINES.
     * @return view
     */
    public function getAirlineLayout()
    {

        $airlines = Airline::get();

        return view('pages/airline', [
            'airlines' => $airlines
        ]);
    }

    public function postDestiny( Request $request )
    {
        $request->validate([
            'destiny_name'          => ['required', 'unique:destinations'],
            'fileDestinyPortuguese' => ['mimes:wav'],
            'fileDestinyEnglish'    => ['mimes:wav']
        ]);

        $obDestiny = new Destination;

        $dirEnglishAudio    = $request->file('fileDestinyEnglish')->store('audios/ing/destiny');
        $dirPortugueseAudio = $request->file('fileDestinyPortuguese')->store('audios/pt/destiny');

        $obDestiny->destiny_name = $request->destiny_name;
        $obDestiny->destiny_ing_audio_path = $dirEnglishAudio;
        $obDestiny->destiny_pt_audio_path = $dirPortugueseAudio;
        if ($obDestiny->save()) {

            Log::create([
                'afect' => 'destinations',
                'context' => 'destination ['. $request->destiny_name . '] created',
                'type'    => 'added',
                'fk_user' => Auth::user()->id,
            ]);
            return back()->with('message', 'Destination was successfully added.');
        }
        return back()->withErrors('An error occurred while adding the destination');
    }

    public static function updateDestiny( Request $request, $id)
    {
        $request->validate([
            'destiny_name' => ['required']
        ]);

        if ($request->hasFile('fileDestinyPortuguese')) {
            $dirPortugueseAudio = $request->file('fileDestinyPortuguese')->store('audios/pt/destiny');
        }

        if ($request->hasFile('fileDestinyEnglish')) {
            $dirEnglishAudio = $request->file('fileDestinyEnglish')->store('audios/ing/destiny');
        }

        $destiny = Destination::findOrFail($id);
        $destiny->destiny_name = $request->destiny_name;
        $destiny->destiny_ing_audio_path = $dirEnglishAudio ?? $destiny->destiny_ing_audio_path;
        $destiny->destiny_pt_audio_path = $dirPortugueseAudio ?? $destiny->destiny_pt_audio_path;

        if ($destiny->save()) {
            Log::create([
                'afect'   => 'destinations',
                'context' => 'destination ['. $request->destiny_name . '] updated',
                'type'    => 'updated',
                'fk_user' => Auth::user()->id,
            ]);
            return back()->with('message', 'Destination was successfully updated.');
        }

        return back()->withErrors('An error occurred while trying to update the destination');
    }

    public function deleteDestiny($id)
    {
        $destiny = Destination::findOrFail($id)->first();

        try {
            Destination::findOrFail($id)->delete();
            unlink(storage_path('../public/storage') . '/' . $destiny->destiny_ing_audio_path);
            unlink(storage_path('../public/storage') . '/' . $destiny->destiny_pt_audio_path);
        } catch ( \Exception $e ) {
            return back()->withErrors("you can't delete the destination because there are associated flights");
        }
        Log::create([
            'afect'   => 'destinations',
            'context' => 'destination ['. $destiny->destiny_name . '] was deleted',
            'type'    => 'deleted',
            'fk_user' => Auth::user()->id,
        ]);
        
        return back();        
    }

    public function postReason( Request $request )
    {
        $request->validate([
            'reason'          => ['required', 'unique:reasons'],
            'fileReasonPortuguese' => ['mimes:wav'],
            'fileReasonEnglish'    => ['mimes:wav']
        ]);

        $obReason = new Reason;

        $dirEnglishAudio    = $request->file('fileReasonEnglish')->store('audios/ing/reason');
        $dirPortugueseAudio = $request->file('fileReasonPortuguese')->store('audios/pt/reason');

        $obReason->reason = $request->reason;
        $obReason->reason_ing_audio_path = $dirEnglishAudio;
        $obReason->reason_pt_audio_path = $dirPortugueseAudio;
        if ($obReason->save()) {

            Log::create([
                'afect'   => 'reasons',
                'context' => 'reason ['. $request->reason . '] was deleted',
                'type'    => 'added',
                'fk_user' => Auth::user()->id,
            ]);

            return back()->with('message', 'Reason was successfully added.');
        }
        return back()->withErrors('An error occurred while adding the reason');
    }

    public function deleteReason($id)
    {
        $reason = Reason::findOrFail($id)->first();

        try {
            Reason::findOrFail($id)->delete();
            unlink(storage_path('../public/storage') . '/' . $reason->reason_ing_audio_path);
            unlink(storage_path('../public/storage') . '/' . $reason->reason_pt_audio_path);
        } catch ( \Exception $e ) {
            return back()->withErrors("you can't delete the reason because there are associated flights");
        }
        Log::create([
            'afect'   => 'reasons',
            'context' => 'reason ['. $reason->reason . '] was deleted',
            'type'    => 'deleted',
            'fk_user' => Auth::user()->id,
        ]);
        
        return back();        
    }

    public function updateReason( Request $request, $id)
    {
        $request->validate([
            'reason' => ['required'],
        ]);

        if ($request->hasFile('fileReasonPortuguese')) {
            $dirPortugueseAudio = $request->file('fileReasonPortuguese')->store('audios/pt/reason');
        }

        if ($request->hasFile('fileReasonEnglish')) {
            $dirEnglishAudio = $request->file('fileReasonEnglish')->store('audios/ing/reason');
        }

        $reason = Reason::findOrFail($id);
        $reason->reason = $request->reason;
        $reason->reason_ing_audio_path = $dirEnglishAudio ?? $reason->reason_ing_audio_path;
        $reason->reason_pt_audio_path = $dirPortugueseAudio ?? $reason->reason_pt_audio_path;

        if ($reason->save()) {
            Log::create([
                'afect'   => 'reasons',
                'context' => 'reason ['. $request->reason . '] updated',
                'type'    => 'updated',
                'fk_user' => Auth::user()->id,
            ]);
            return back()->with('message', 'Reason was successfully updated.');
        }

        return back()->withErrors('An error occurred while trying to update the reason');
    }

    /**
     * METODO RESPONSAVEL POR REGISTRAR UMA NOVA COMPANIA AERIA
     * @param Request $request
     */
    public static function postAirline(Request $request)
    {
        $request->validate([
            'airline_name'          => ['required', 'unique:airlines'],
            'fileAirlinePortuguese' => ['required', 'mimes:wav'],
            'fileAirlineEnglish'    => ['required', 'mimes:wav']
        ]);

        $obAirline = new Airline;

        $dirEnglishAudio = $request->file('fileAirlineEnglish')->store('audios/ing/airline');
        $dirPortugueseAudio = $request->file('fileAirlinePortuguese')->store('audios/pt/airline');

        $obAirline->airline_name = $request->airline_name;
        $obAirline->airline_ing_audio_path = $dirEnglishAudio;
        $obAirline->airline_pt_audio_path = $dirPortugueseAudio;
        if ($obAirline->save()) {

            Log::create([
                'afect'   => 'airlines',
                'context' => 'airline ['. $request->airline_name . '] was added',
                'type'    => 'added',
                'fk_user' => Auth::user()->id,
            ]);

            return back()->with('message', 'Airline was successfully added.');
        }

        return back()->withErrors('An error occurred while adding the airline');
    }

    public static function deleteAirline($id)
    {
        $airline = Airline::findOrFail($id)->first();
        Log::create([
            'afect'   => 'airlines',
            'context' => 'airline ['. $airline->airline_name . '] was deleted',
            'type'    => 'deleted',
            'fk_user' => Auth::user()->id,
        ]);
        try {
            Airline::findOrFail($id)->delete();
            unlink(storage_path('../public/storage') . '/' . $airline->airline_ing_audio_path);
            unlink(storage_path('../public/storage') . '/' . $airline->airline_pt_audio_path);
        } catch( \Exception $e ) {
            return back()->withErrors("you can't delete the airline because there are associated flights");
        }
        
        return back();
    }

    public function updateAirline(Request $request, $id)
    {

        $request->validate([
            'airlineName' => ['required']
        ]);

        if ($request->hasFile('fileAirlinePortuguese')) {
            $dirPortugueseAudio = $request->file('fileAirlinePortuguese')->store('audios/pt/airline');
        }

        if ($request->hasFile('fileAirlineEnglish')) {
            $dirEnglishAudio = $request->file('fileAirlineEnglish')->store('audios/ing/airline');
        }

        $airline = Airline::findOrFail($id);

        $airline->airline_name = $request->airlineName;
        $airline->airline_ing_audio_path = $dirEnglishAudio ?? $airline->airline_ing_audio_path;
        $airline->airline_pt_audio_path  = $dirPortugueseAudio ?? $airline->airline_pt_audio_path;

        if ($airline->save()) {
            Log::create([
                'afect'   => 'airlines',
                'context' => 'airline ['. $airline->airline_name . '] was updated',
                'type'    => 'updated',
                'fk_user' => Auth::user()->id,
            ]);
            return back()->with('message', 'Airline was successfully updated.');
        }

        return back()->withErrors('An error occurred while trying to update airline');
    }

    public function deleteGate($id)
    {
        // $obLog = new Log;
        // $obLog->afect        = 'gates';
        // $obLog->type         = 'deleted';
        // $obLog->afected_name = (new Gate)->where('gate_id', $id)->first()->gate_no;
        // $obLog->fk_user = user()->id;
        // $obLog->create();
        $gate = Gate::findOrFail($id)->first();
        
        try {
            Gate::findOrFail($id)->delete();
            unlink(storage_path('../public/storage') . '/' . $gate->gate_ing_audio_path);
            unlink(storage_path('../public/storage') . '/' . $gate->gate_pt_audio_path);
        } catch ( \Exception $e ) {
            return back()->withErrors("you can't delete the gate because there are associated flights");
        }
        
        return back();
    }

    public function postGate(Request $request)
    {

        $request->validate([
            'gate_no'            => ['required', 'numeric', 'unique:gates'],
            'fileGatePortuguese' => ['mimes:wav', 'required'],
            'fileGateEnglish'    => ['mimes:wav', 'required']
        ], [
            'gate_no.required'   => 'The gate number field is required.',
            'gate_no.numeric'   => 'The gate number field must be a number.',
        ]);

        $obGate = new Gate;

        $dirPortugueseAudio = $request->file('fileGatePortuguese')->store('audios/pt/gate');
        $dirEnglishAudio = $request->file('fileGateEnglish')->store('audios/ing/gate');

        $obGate->gate_no = $request->gate_no;
        $obGate->gate_ing_audio_path = $dirEnglishAudio;
        $obGate->gate_pt_audio_path = $dirPortugueseAudio;
        if ($obGate->save()) {
            Log::create([
                'afect'   => 'gates',
                'context' => 'gate ['. $request->gate_no . '] was added',
                'type'    => 'added',
                'fk_user' => Auth::user()->id,
            ]);
            return back()->with('message', 'Gate was successfully added.');
        }

        return back()->withErrors('An error occurred while adding the gate');
    }

    public static function updateGate(Request $request, $id)
    {

        $request->validate([
            'gate_no' => ['number', 'required']
        ]);

        if ($request->hasFile('fileGatePortuguese')) {
            $dirPortugueseAudio = $request->file('fileGatePortuguese')->store('audios/pt/gate');
        }

        if ($request->hasFile('fileGateEnglish')) {
            $dirEnglishAudio = $request->file('fileGateEnglish')->store('audios/ing/gate');
        }

        $gate = Gate::findOrFail($id);

        $gate->gate_no = $request->gate_no;
        $gate->gate_ing_audio_path = $dirEnglishAudio ?? $gate->gate_ing_audio_path;
        $gate->gate_pt_audio_path =  $dirPortugueseAudio ?? $gate->gate_pt_audio_path;

        if ($gate->save()) {

            Log::create([
                'afect'   => 'gates',
                'context' => 'gate ['. $request->gate_no . '] was updated',
                'type'    => 'updated',
                'fk_user' => Auth::user()->id,
            ]);

            return back()->with('message', 'gate was succesfully updated');
        }

        return back()->withErrors('An error ocurred while trying to update gate');
    }
}
