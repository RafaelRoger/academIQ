<?php

namespace App\Http\Controllers;

use App\Models\Flight;
use App\Models\Gate;
use Illuminate\Http\Request;

class Departures extends Controller
{

    public function getDepartures()
    {
        $flights = Flight::select([
            'flights.*',
            'gates.gate_no',
            'gates.gate_ing_audio_path',
            'gates.gate_pt_audio_path',
            'airlines.airline_name',
            'airlines.airline_ing_audio_path',
            'airlines.airline_pt_audio_path',
            "destiny1.destiny_name as destiny1_name",
            "destiny1.destiny_ing_audio_path as destiny1_ing_audio_path",
            "destiny1.destiny_pt_audio_path as destiny1_pt_audio_path",
            "destiny2.destiny_name as destiny2_name",
            "destiny2.destiny_ing_audio_path as destiny2_ing_audio_path",
            "destiny2.destiny_pt_audio_path as destiny2_pt_audio_path"
        ])
            ->leftjoin('destinations as destiny1', 'destiny1.id', 'flights.flight_destiny_id')
            ->leftjoin('destinations as destiny2', 'destiny2.id', 'flights.flight_destiny2_id')
            ->join('airlines', 'flights.flight_airline_id', 'airlines.id')
            ->join('gates', 'flights.flight_gate_id', 'gates.id')
            ->where('flights.type', "departure")
            ->orderByDesc('flights.id')
            ->get();

        $gates = Gate::get();


        return view('pages.departures', [
            'datasets' => $flights,
            'gates'   => $gates,
            'type'    => 'departures'
        ]);
    }

    /**
     * METODO RESPONSAVEL POR REGISTRAR UM NOVO VOO
     * @param Request $request
     */
    public function updateGate(Request $request, $id)
    {

        $request->validate([
            'gate'    => ['numeric'],
        ]);

        $obFlight = Flight::findOrFail($id);
        $obFlight->flight_gate_id    = $request->gate;
        $obFlight->save();

        return back();
    }
}
