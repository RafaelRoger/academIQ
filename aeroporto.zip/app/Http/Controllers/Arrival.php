<?php

namespace App\Http\Controllers;

use App\Models\Flight;
use Illuminate\Http\Request;

class Arrival extends Controller
{
    public function invoke()
    {

        $flights = Flight::with('airline')->where('type', 'arrive')->get();
        return view('pages/arrival', [
            'flights' => $flights
        ]);
    }
}
