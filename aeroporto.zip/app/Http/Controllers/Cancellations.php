<?php

namespace App\Http\Controllers;

use App\Models\Cancellation;
use App\Models\Flight;
use App\Models\Reason;
use Illuminate\Http\Request;

class Cancellations extends Controller
{


    public function getCancellations()
    {
        $cancellations = Cancellation::select([
            'flights.*',
            'reasons.*',
            'airlines.*',
            'cancellations.id as cancellation_id',
            'cancellations.reason_id',
            "destiny1.destiny_name as destiny1_name",
            "destiny1.destiny_ing_audio_path as destiny1_ing_audio_path",
            "destiny1.destiny_pt_audio_path as destiny1_pt_audio_path",
            "destiny2.destiny_name as destiny2_name",
            "destiny2.destiny_ing_audio_path as destiny2_ing_audio_path",
            "destiny2.destiny_pt_audio_path as destiny2_pt_audio_path"
        ])
            ->join('flights', 'cancellations.flight_id', 'flights.id')
            ->join('reasons', 'cancellations.reason_id', 'reasons.id')
            ->leftjoin('airlines', 'airlines.id', 'flights.flight_airline_id')
            ->leftjoin('destinations as destiny1', 'destiny1.id', 'flights.flight_destiny_id')
            ->leftjoin('destinations as destiny2', 'destiny2.id', 'flights.flight_destiny2_id')
            ->where('flights.type', "cancellation")
            ->orderByDesc('cancellations.id')
            ->get();
        $flights = Flight::select([
            'flights.*',
            'gates.gate_no',
            'gates.gate_ing_audio_path',
            'gates.gate_pt_audio_path',
            'airlines.airline_name',
            'airlines.airline_ing_audio_path',
            'airlines.airline_pt_audio_path',
            "destiny1.destiny_name as destiny1_name",
            "destiny1.destiny_ing_audio_path as destiny1_ing_audio_path",
            "destiny1.destiny_pt_audio_path as destiny1_pt_audio_path",
            "destiny2.destiny_name as destiny2_name",
            "destiny2.destiny_ing_audio_path as destiny2_ing_audio_path",
            "destiny2.destiny_pt_audio_path as destiny2_pt_audio_path"
        ])
            ->leftjoin('destinations as destiny1', 'destiny1.id', 'flights.flight_destiny_id')
            ->leftjoin('destinations as destiny2', 'destiny2.id', 'flights.flight_destiny2_id')
            ->join('airlines', 'flights.flight_airline_id', 'airlines.id')
            ->join('gates', 'flights.flight_gate_id', 'gates.id')
            ->where('flights.type', "!=", "cancellation")
            ->orderByDesc('flights.id')
            ->get();

        $reasons = Reason::get();
        return view('pages/cancellations', [
            'dataset'  => $cancellations,
            'reasons' => $reasons,
            'flightsArr' => $flights
        ]);
    }

    public function postCancellation(Request $request)
    {

        $request->validate([
            'flight_id'  => ['required', 'numeric'],
            'reason_id' => ['required', 'numeric']
        ]);

        $flightObj = Flight::findOrFail($request->flight_id);
        $flightObj->type = "cancellation";
        if ($flightObj->save()) {
            $cancellationObj = new Cancellation;
            $cancellationObj->flight_id = $request->flight_id;
            $cancellationObj->reason_id = $request->reason_id;
            $cancellationObj->save();

            return back()->with('message', 'successfully canceled flight');
        }

        return back()->withErrors('An error occurred while adding the destination');
    }

    /**
     * METODO RESPONSAVEL POR REGISTRAR UM NOVO VOO
     * @param Request $request
     */
    public function updateCancellation(Request $request, $id)
    {
        $request->validate([
            'reason'    => ['numeric'],
        ]);

        $obCancellation = Cancellation::findOrFail($id);
        $obCancellation->reason_id = $request->reason;
        $obCancellation->save();

        return back()->with('message', 'cancellation reason updated succesfully');
    }

    public function deleteCancellation($id)
    {
        $obCancelation = Cancellation::findOrFail($id)->first();


        $obFlight = Flight::find($obCancelation->flight_id);
        $obFlight->type = "departure";
        $obFlight->save();

        Cancellation::find($id)->delete();
        return back();
    }
}
