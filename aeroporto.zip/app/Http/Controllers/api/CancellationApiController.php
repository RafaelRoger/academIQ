<?php

namespace App\Http\Controllers\api;

use App\Http\Controllers\Controller;
use App\Models\Cancellation;
use Illuminate\Http\Request;

class CancellationApiController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        return Cancellation::all();
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
        $cancellations = Cancellation::select([
            'flights.*',
            'reasons.*',
            'airlines.*',
            'cancellations.*',
            "destiny1.destiny_name as destiny1_name",
            "destiny1.destiny_ing_audio_path as destiny1_ing_audio_path",
            "destiny1.destiny_pt_audio_path as destiny1_pt_audio_path",
            "destiny2.destiny_name as destiny2_name",
            "destiny2.destiny_ing_audio_path as destiny2_ing_audio_path",
            "destiny2.destiny_pt_audio_path as destiny2_pt_audio_path"
        ])
            ->join('flights', 'cancellations.flight_id', 'flights.id')
            ->join('reasons', 'cancellations.reason_id', 'reasons.id')
            ->leftjoin('airlines', 'airlines.id', 'flights.flight_airline_id')
            ->leftjoin('destinations as destiny1', 'destiny1.id', 'flights.flight_destiny_id')
            ->leftjoin('destinations as destiny2', 'destiny2.id', 'flights.flight_destiny2_id')
            ->where('cancellations.id', $id)
            ->orderByDesc('cancellations.id')
            ->first();

        $flightName = explode(',', $cancellations->flight);
        $cancellations->flight = $flightName;

        return $cancellations;
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
