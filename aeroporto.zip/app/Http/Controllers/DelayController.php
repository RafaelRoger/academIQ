<?php

namespace App\Http\Controllers;

use App\Models\Delay;
use App\Models\Flight;
use Illuminate\Http\Request;

class DelayController extends Controller
{
    //
    public function invoke()
    {
        $flightsDelay = Delay::with('flight.airline', 'flight.destiny1')->get();

        $flights = Flight::with('airline')->get();
        return view('pages/delay', [
            'dataset' => $flightsDelay,
            'flights' => $flights
        ]);
    }

    public function store(Request $request)
    {
        $request->validate([
            'hour'      => 'required',
            'flight_id' => 'required|unique:delays',
        ]);

        $hour =  explode(':', $request->hour);

        $delay = new Delay;
        $delay->flight_id = $request->flight_id;
        $delay->hour      = $hour[0];
        $delay->minute    = $hour[1];
        $delay->save();

        return back()->with('message', 'Delay succesfully added.');
    }

    public function update( Request $request, string $id )
    {
        $request->validate([
            'flight_id' => 'required',
            'hour'      => 'required',
        ]);

        $hour =  explode(':', $request->hour);

        $delay = Delay::findOrFail($id);
        $delay->flight_id = $request->flight_id;
        $delay->hour      = $hour[0];
        $delay->minute    = $hour[1];
        $delay->save();

        return back()->with('message', 'Delay succesfully updated.');
    }

    public function destroy($id)
    {
        Delay::findOrFail($id)->delete();
        return back();
    }
}
