<?php

namespace App\Http\Controllers;

use App\Models\Log;

class History extends Controller
{

    public function show($name)
    {
        $data = Log::with('user')->where('logs.afect', $name)->get();

        return view('pages/history', [
            'logs' => $data,
            'where' => $name,
        ]);
    }
}
