<?php

namespace App\Http\Controllers;

use \App\Models\ChackIn;
use App\Models\Flight;
use Illuminate\Http\Request;

class CheckInController extends Controller
{
    /**
     * method responsible for store flight on check in 
     * @param Request $request
     */
    public function store(Request $request)
    {
        $request->validate(
            [
                'flight_id' => 'required',
                'counter'   => 'required',
                'type'      => 'required',
            ]
        );
        //WWdd(implode(',', $request->counter));
        $checkIn = new ChackIn;
        $checkIn->flight_id = $request->flight_id;
        $checkIn->counter = implode(',', $request->counter);
        $checkIn->type    = $request->type;
        $checkIn->save();

        return back()->with('message', 'check in to flight, succesfully added');
    }

    /**
     * method responsible for returning the view with the list of flights at check in
     */
    public function show()
    {
        $dataset = ChackIn::with('flight.airline')->orderByDesc('id')->get();
        $flights = Flight::with('airline')->get();
        
        return view('pages/check-in', [
            'dataset' => $dataset,
            'flights' => $flights
        ]);
    }

    /**
     * metodo responsavel por remover um anuncio de check in
     * @param int $id
     */
    public function remove( $id )
    {
        ChackIn::findOrFail($id)->delete();
        return back();
    }
}
