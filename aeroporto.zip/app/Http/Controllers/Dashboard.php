<?php

namespace App\Http\Controllers;

use App\Models\Airline;
use App\Models\Destination;
use App\Models\Gate;

class Dashboard extends Controller {

    public static function getDashboard() {
        
        $gates = Gate::get();
        $airlines = Airline::get();
        $destinys = Destination::get();

        return view('pages/dashboard', [
            'gates'        => $gates,
            'airlines'     => $airlines,
            'destinys'     => $destinys
        ]);
    }
    /**
     * METODO RESPONSAVEL POR REGISTRAR UMA NOVA GATE
     * @param Request $request
     */
    public static function postGate( $request ) {
        
        $postVars = $request->getPostVars();

        $status = $request->validate([
            'gate_no'            => ['required', 'number','unique:gates'],
            'fileGatePortuguese' => ['mimes:wav'],
            'fileGateEnglish'    => ['mimes:wav']
        ]);

        if ($status) {
            $obGate = new Gate;

            $uploadPt = new Upload($_FILES['fileGatePortuguese']);
            $uploadPt->generateNewName();
            if ($uploadPt->Upload(__DIR__.'/../../../audios/PT/GateNo', false)) {
                $uploadEn = new Upload($_FILES['fileGateEnglish']);
                $uploadEn->generateNewName();
                if ($uploadEn->Upload(__DIR__.'/../../../audios/ING/GateNo')) {
                    $obGate->gate_no = $postVars['gate_no'];
                    $obGate->gate_ing_audio_path = './audios/ING/GateNo/'.$uploadEn->getBasename();
                    $obGate->gate_pt_audio_path = './audios/PT/GateNo/'.$uploadPt->getBasename();
                    if ($obGate->create()) {
                        $message[] = 'Gate has successfull registred';
                    }
                }
            } else {
                $message[] = 'Problems with upload file';
            }
        } else {
           $message = $request->getErrorMessages();
        }

        return self::getDashboard($message ?? null);
    }

     /**
     * METODO RESPONSAVEL POR REGISTRAR UM NOVO VOO
     * @param Request $request
     */
    public static function postFlight( $request ) {
        $postVars = $request->getPostVars();
        $status = $request->validate([
            'flight'  => ['required'/*, 'unique:flights'*/],
            'destiny' => ['required', 'number'],
            'destiny2' => ['number'],
            'airline' => ['required', 'number'],
            'gate'    => ['required', 'number'],
        ]);
        $i = 0;
        $num = [];
        while(true) {
            if (!isset($postVars['flight'][$i])) break;
            $num[] = $postVars['flight'][$i]; 
            $i++;
        }
        if ($status) {
            $obFlight = new Flight();
            $obFlight->flight            = implode(',',$num);
            $obFlight->flight_airline_id = $postVars['airline'];
            $obFlight->flight_destiny_id = $postVars['destiny'];
            $obFlight->flight_destiny2_id = $postVars['destiny2'] == 'null' ? null : $postVars['destiny2'];
            $obFlight->flight_gate_id    = $postVars['gate'];
            $obFlight->type              = $postVars['type'];

            if ($obFlight->create()) {
                $message[] = 'Flight has successfull registred';
            }
        } else {
            $message = $request->getErrorMessages();
        }

        return self::getDashboard($message ?? null);
    }

     /**
     * METODO RESPONSAVEL POR REGISTRAR UMA NOVA COMPANIA AERIA
     * @param Request $request
     */
    public static function postAirline( $request ) {
        $postVars = $request->getPostVars();

        $status = $request->validate([
            'airline_name'          => ['required', 'number','unique:airlines'],
            'fileAirlinePortuguese' => ['required','mimes:wav'],
            'fileAirlineEnglish'    => ['required','mimes:wav']
        ]);

        if ($status) {

            $obAirline = new Airline;

            $uploadPt = new Upload($_FILES['fileAirlinePortuguese']);
            $uploadPt->generateNewName();
            if ($uploadPt->Upload(__DIR__.'/../../../audios/PT', false)) {
                $uploadEn = new Upload($_FILES['fileAirlineEnglish']);
                $uploadEn->generateNewName();
                if ($uploadEn->Upload(__DIR__.'/../../../audios/ING')) {
                    $obAirline->airline_name = $postVars['airlineName'];
                    $obAirline->airline_ing_audio_path = './audios/ING/'.$uploadEn->getBasename();
                    $obAirline->airline_pt_audio_path = './audios/PT/'.$uploadPt->getBasename();
                    if ($obAirline->create()) {
                        $message[] = 'Airline has successful created';
                    }
                }
            } else {
                $message[] = 'Problems with upload file';
            }
        } else {
            $message = $request->getErrorMessages();
        }
        return self::getDashboard($message ?? null);
    }

     /**
     * METODO RESPONSAVEL POR REGISTRAR UM NOVO DESTINO
     * @param Request $request
     */
    public static function postDestiny( $request ) {
        $postVars = $request->getPostVars();

        $status = $request->validate([
            'destiny_name'          => ['required','unique:destinys'],
            'fileDestinyPortuguese' => ['mimes:wav'],
            'fileDestinyEnglish'    => ['mimes:wav']
        ]);

        if ($status) {
            $obDestiny = new Destiny;
            
            $uploadPt = new Upload($_FILES['fileDestinyPortuguese']);
            $uploadPt->generateNewName();
            if ($uploadPt->Upload(__DIR__.'/../../../audios/PT/city', false)) {
                $uploadEn = new Upload($_FILES['fileDestinyEnglish']);
                $uploadEn->generateNewName();
                if ($uploadEn->Upload(__DIR__.'/../../../audios/ING/city')) {
                    $obDestiny->destiny_name = $postVars['destiny_name'];
                    $obDestiny->destiny_ing_audio_path = './audios/ING/city/'.$uploadEn->getBasename();
                    $obDestiny->destiny_pt_audio_path = './audios/PT/city/'.$uploadPt->getBasename();
                    if ($obDestiny->create()) {
                        $message[] = 'Destiny has successfull created';
                    }
                }
            } else {
                $message[] = 'Problems with upload file';
            }
        } else {
           $message = $request->getErrorMessages();
        }

        return self::getDashboard($message ?? null);
        
    }

}