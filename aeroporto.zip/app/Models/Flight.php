<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Flight extends Model
{
    use HasFactory;

    protected $fillable = [
        'flight',
        'flight_destiny_id',
        'flight_destiny2_id',
        'flight_airline_id',
        'flight_gate_id',
        'type',
    ];

    public function airline() {
        return $this->belongsTo(Airline::class, 'flight_airline_id');
    }

    public function gates() {
        return $this->belongsTo(Gate::class, 'flight_gate_id');
    }

    public function destiny1() {
        return $this->belongsTo(Destination::class, 'flight_destiny_id');
    }

    public function destiny2() {
        return $this->belongsTo(Destination::class, 'flight_destiny2_id');
    }
}
