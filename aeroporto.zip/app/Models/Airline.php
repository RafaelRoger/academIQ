<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Airline extends Model
{
    use HasFactory;

    protected $fillable = [
        'airline_name',
        'airline_ing_audio_path',
        'airline_pt_audio_path',
    ];

    public function flights() {
        $this->hasMany(Flight::class);
    }
}
