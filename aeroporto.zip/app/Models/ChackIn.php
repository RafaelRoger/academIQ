<?php

namespace App\Models;

use App\Http\Controllers\Flights;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ChackIn extends Model
{
    use HasFactory;

    protected $fillable = [
        'flight_id',
        'counter',
    ];

    public function flight() {
        return $this->belongsTo(Flight::class, 'flight_id');
    }
}
