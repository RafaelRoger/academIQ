<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('flights', function (Blueprint $table) {
            $table->id();
            $table->string('flight');
            $table->unsignedBigInteger('flight_destiny_id');
            $table->foreign('flight_destiny_id')->references('id')->on('destinations')->onUpdate('cascade');
            $table->unsignedBigInteger('flight_destiny2_id')->nullable();
            $table->foreign('flight_destiny2_id')->references('id')->on('destinations')->onUpdate('cascade');
            $table->unsignedBigInteger('flight_airline_id');
            $table->foreign('flight_airline_id')->references('id')->on('airlines')->onUpdate('cascade');
            $table->unsignedBigInteger('flight_gate_id')->nullable();
            $table->foreign('flight_gate_id')->references('id')->on('gates')->onUpdate('cascade');
            $table->enum('type', [
                'departure',
                'arrive',
                'cancellation'
            ]);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('flights');
    }
};
