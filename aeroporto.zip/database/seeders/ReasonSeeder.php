<?php

namespace Database\Seeders;

use App\Models\Reason;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class ReasonSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        Reason::create([
            'reason' => 'Air trafic congestion',
            'reason_ing_audio_path' => 'audios/ing/reason/AA.wav',
            'reason_pt_audio_path' => 'audios/pt/reason/AA.wav',
        ]);

        Reason::create([
            'reason' => 'The maintenence of the aircraft',
            'reason_ing_audio_path' => 'audios/ing/reason/BB.wav',
            'reason_pt_audio_path' => 'audios/pt/reason/BB.wav',
        ]);

        Reason::create([
            'reason' => 'The pour weather condition at out airport',
            'reason_ing_audio_path' => 'audios/ing/reason/DD.wav',
            'reason_pt_audio_path' => 'audios/pt/reason/DD.wav',
        ]);

        Reason::create([
            'reason' => 'The pour weather condition over the route',
            'reason_ing_audio_path' => 'audios/ing/reason/EE.wav',
            'reason_pt_audio_path' => 'audios/pt/reason/EE.wav',
        ]);

        Reason::create([
            'reason' => 'The pour weather condition over that airport',
            'reason_ing_audio_path' => 'audios/ing/reason/FF.wav',
            'reason_pt_audio_path' => 'audios/pt/reason/FF.wav',
        ]);

        Reason::create([
            'reason' => 'The close_down of that airport',
            'reason_ing_audio_path' => 'audios/ing/reason/GG.wav',
            'reason_pt_audio_path' => 'audios/pt/reason/GG.wav',
        ]);

        Reason::create([
            'reason' => 'Aircraft reallocation',
            'reason_ing_audio_path' => 'audios/ing/reason/HH.wav',
            'reason_pt_audio_path' => 'audios/pt/reason/HH.wav',
        ]);
    }
}
